import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class Main {

    private static Map<String, Person> peoples = new LinkedHashMap<>();
    private static Map<String, Product> products = new LinkedHashMap<>();
    static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));


    public static void main(String[] args)  {

        try {
            setInput("person");
            setInput("product");

            String input;
            while(!("END").equalsIgnoreCase(input = reader.readLine())) {
                String[] inputs = input.split("\\s+");
                String name = inputs[0];
                String productName = inputs[1];
                if (peoples.containsKey(name) && products.containsKey(productName)){
                    Person person = peoples.get(name);
                    Product product = products.get(productName);
                    person.buyProduct(product);
                }
            }
        } catch (IllegalArgumentException iae) {
            System.out.println(iae.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }
        peoples.values().forEach(System.out::println);
    }

    private static void setInput(String command) throws IOException {
        String[] input = getInput();
        for (int i = 0; i < input.length; i+=2) {
            String name = input[i];
            double money = Double.parseDouble(input[i+1]);
            if(command.equals("person")){
                peoples.putIfAbsent(name, new Person(name, money));
            } else if (command.equals("product")){
                products.putIfAbsent(name, new Product(name, money));
            }
        }

    }

    private static String[] getInput() throws IOException {
        return reader.readLine().split("[=;]");
    }
}
